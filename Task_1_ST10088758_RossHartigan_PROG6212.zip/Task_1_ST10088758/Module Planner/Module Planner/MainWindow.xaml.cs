﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using moduleLibrary;

namespace Module_Planner
{

    public partial class MainWindow : Window
    {
        int count = 0; 
        List<Module> modulesList = new List<Module>();
        List<WeeklyHours> weeklyHoursList = new List<WeeklyHours>();

        public MainWindow()
        {
            InitializeComponent();            
        }

        private void moduleSubmit_Click(object sender, RoutedEventArgs e)
        {
            count++;
            
            Module module = new Module();

            string moduleReport = "";
            double selfStudy = 0;

            string code = moduleCode.Text;
            string name = moduleName.Text;
            int credits = Convert.ToInt32(moduleCredits.Text);
            int hours = Convert.ToInt32(classHours.Text);
            int semesterWeekHours = Convert.ToInt32(semesterWeeks.Text);
            string date = startDate.Text;

            module.ModuleCode = code;
            module.ModuleName = name;
            module.Credits = credits;
            module.WeekHours = hours;
            module.SemesterWeeks = semesterWeekHours;
            module.StartDate = date; 

            selfStudy = module.CalcSelfStudyHours();
            module.SelfStudyHours = selfStudy;

            module.AddModule();
            modulesList.Add(module);

            foreach (var x in modulesList)
            {
                moduleReport = moduleReport + ($"Code : {x.ModuleCode} \nName : {x.ModuleName} \nSelf-Study Hours per week : {x.SelfStudyHours}\n");                
            }

            reportBox.Text = (moduleReport);

            moduleList.Items.Clear();

            foreach (var x in modulesList)
            {
                moduleList.Items.Add(x.ModuleCode);
            }

        }

        public void hoursSubmit_Click(object sender, RoutedEventArgs e)
        {
            WeeklyHours weeklyHours = new WeeklyHours();

            int hours = Convert.ToInt32(hoursWorked.Text);
            string date = workDate.Text;


            weeklyHours.HoursWorked = hours;
            weeklyHours.Date = date;

            weeklyHours.AddDate();
            weeklyHoursList.Add(weeklyHours);

            string[] list = moduleList.Items.OfType<string>().ToArray();
            int moduleIndex = moduleList.SelectedIndex;
            string moduleQuery = list[moduleIndex];

            var query = from cust
                                in modulesList
                                where cust.ModuleCode == moduleQuery
                                select cust;

            foreach (var x in query)
            {
                x.SelfStudyHours = (x.SelfStudyHours - hours);
            }
        }

        public void finalSubmit_Click(object sender, RoutedEventArgs e)
        {
            string[] list = moduleList.Items.OfType<string>().ToArray();
            int moduleIndex = moduleList.SelectedIndex;
            string moduleQuery = list[moduleIndex];

            var query = from cust
                                in modulesList
                                where cust.ModuleCode == moduleQuery
                                select cust;

            foreach (var x in query)
            {
                queryBox.Text = $"Module Code : {x.ModuleCode} \n\nHours still needed to work this week : {x.SelfStudyHours} hours";
            }
        }
    }
}
