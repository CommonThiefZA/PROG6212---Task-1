﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace moduleLibrary
{
    public class WeeklyHours
    {
        private List<WeeklyHours> hoursList = new List<WeeklyHours>();

        private int hoursWorked;
        private string date;

        public WeeklyHours()
        {
            hoursWorked = 0;
            date = "";
        }

        public WeeklyHours(int hoursWorked, string date)
        {
            this.hoursWorked = hoursWorked;
            this.date = date;
        }

        public int HoursWorked
        {
            get { return hoursWorked; }
            set { hoursWorked = value; }
        }

        public string Date
        {
            get { return date; }
            set { date = value; }
        }

        public List<WeeklyHours> ListHours
        {
            get { return hoursList; }
            set { hoursList = value; }
        }

        public void AddDate()
        {
            int hours = HoursWorked;
            string date1 = Date;            

            hoursList.Add(new WeeklyHours(hours, date1));
        }
    }
}
